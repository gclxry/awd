#include <windows.h>

void __cdecl main ( )
{
    LoadLibrary(L"10moddll.dll");

    //
    // Use ModDll.DLL 
    //
}
